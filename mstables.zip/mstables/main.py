#!/usr/bin/env python

from shutil import copyfile
from importlib import reload
import fetch
import time
import os
import re
import sys

__author__ = "Caio Brandao", "Andrew Schell"
__copyright__ = "Copyright 2019+, Caio Brandao"
__license__ = "MIT"
__version__ = "0.1.2"
__maintainer__ = "Andrew Schell"
__email__ = "andrewschell3@gmail.com"


def override_where():
    """
    overrides certifi.core.where to return actual location of cacert.pem
    :return:
    """
    # change this to match the location of cacert.pem
    return os.path.abspath("cacert.pem")


# is the program compiled?
if hasattr(sys, "frozen"):
    import certifi.core

    os.environ["REQUESTS_CA_BUNDLE"] = override_where()
    certifi.core.where = override_where

    # delay importing until after where() has been replaced
    import requests.utils
    import requests.adapters

    # replace these variables in case these modules were
    # imported before we replaced certifi.core.where
    requests.utils.DEFAULT_CA_BUNDLE_PATH = override_where()
    requests.adapters.DEFAULT_CA_BUNDLE_PATH = override_where()


# Create back-up file under /db/backup
def backup_db(file):
    """
    Gives user ability to enter, fetch or backup file
    :param file:
    :return:
    """
    # today = datetime.today().strftime('%Y%m%d%H')
    new_file = db_file["db_backup"].format(input("Enter back-up file name:\n"))
    fetch.print_("Please wait while the database file is backed-up ...")
    copyfile(db_file["path"], new_file)
    return "\n~ Back-up file saved\t{}".format(new_file)


# Change variable for .sqlite file name based on user input
def change_name(old_name):
    """
    Updates the database to a new name provided from user
    :param old_name:
    :return:
    """
    msg = "Existing database files in directory 'db/': {}\n"
    msg += "Enter new name for .sqlite file (current = '{}'):\n"
    fname = lambda x: re.sub(".sqlite", "", x)
    files = [fname(f) for f in os.listdir("db/") if ".sqlite" in f]

    return input(msg.format(files, old_name))


# Print options menu
def print_menu(names):
    """
    Generate menu and prompt user with 7 options - 0 through 6
    :param names:
    :return:
    """
    project_name = ["msTables", "SQL_Template", "placeholder"]
    default_project = project_name[0:1]
    gap = 22
    dash = "="
    banner = f" Welcome to {default_project} "
    file = "db'{}.sqlite'".format(db_file["name"])
    # TODO reorder PEMDAS style, test db exists, test ddl and dml,
    #  test sample of data against DDL and DML and database,
    menu = {
        "0": "Change database file name (current name = {})".format(file),
        "1": "Write database tables and import latest symbols",
        "2": "Download Morningstar data into database",
        "3": "Erase all records from database tables",
        "4": "Delete all database tables",
        "5": "Erase all downloaded history from 'Fetched_urls' table",
        # 'X' : 'Parse (FOR TESTING PURPOSES)',
        "6": "Create a database back-up file",
        # "7": "Scan data folder for .csv, .tsv and parquet files"
        # "8": "Test the data aligns with database"
        # "9": "Filter sus names for regulatory compliance""
    }

    print(dash * (len(banner) + gap * 2))
    print("{}{}{}".format(dash * gap, banner, dash * gap))
    print("\nAvailable actions:\n")
    for k, v in menu.items():
        print(k, "-", v)
    print("\n" + dash * (len(banner) + gap * 2))

    return menu


# Print command line menu for user input
def main(file):
    """
    Print menu and capture user selection
    :param file:
    :return:
    """
    while True:
        ops = print_menu(file)
        while True:
            try:
                inp0 = input("Enter action no.:\n").strip()
                break
            except KeyboardInterrupt:
                print("\nGoodbye!")
                exit()
        if inp0 not in ops.keys():
            break
        reload(fetch)  # Comment out after development
        start = time.time()
        inp = int(inp0)
        ans = "y"

        # Ask user to confirm selection if input > 2
        if inp > 2:
            msg = "\nAre you sure you would like to {}? (Y/n):\n"
            ans = input(msg.format(ops[inp0].upper())).lower()

        # Call function according to user input
        if ans == "y":
            print()
            try:
                # Change db file name
                if inp == 0:
                    db_file["name"] = change_name(db_file["name"])
                    start = time.time()
                    db_file["path"] = db_file["npath"].format(db_file["name"])
                    msg = "~ Database file '{}' selected".format(db_file["name"])

                # Create database tables
                elif inp == 1:
                    msg = fetch.create_tables(db_file["path"])

                # Download data from urls listed in api.json
                elif inp == 2:
                    start = fetch.fetch(db_file["path"])
                    msg = "\n~ Database updated successfully"

                # Erase records from all tables
                elif inp == 3:
                    msg = fetch.erase_tables(db_file["path"])

                # Delete all tables
                elif inp == 4:
                    msg = fetch.delete_tables(db_file["path"])

                # Delete Fetched_urls table records
                elif inp == 5:
                    msg = fetch.del_fetch_history(db_file["path"])

                # Back-up database file
                elif inp == int(list(ops.keys())[-1]):
                    msg = backup_db(db_file)

                # TESTING
                elif inp == 99:
                    model.parse.parse(db_file["path"])
                    msg = "FINISHED"
            # except sqlite3.OperationalError as S:
            #    msg = '### Error message - {}'.format(S) + \
            #        '\n### Scroll up for more details. If table does not ' + \
            #        'exist, make sure to execute action 1 before choosing' + \
            #        ' other actions.'
            #    pass
            # except KeyboardInterrupt:
            #    print('\nGoodbye!')
            #    exit()
            except Exception as e:
                print("\a")
                # print('\n\n### Error @ main.py:\n {}\n'.format(e))
                raise

            # Print output message
            # os.system('clear')
            print(msg)

            # Calculate and print execution time
            end = time.time()
            print("\n~ Execution Time\t{:.2f} sec\n".format(end - start))
        else:
            os.system("clear")


# Define database (db) file and menu text variables
db_file = dict()
db_file["npath"] = "db/{}.sqlite"
db_file["name"] = "mstable"
db_file["path"] = db_file["npath"].format(db_file["name"])
db_file["db_backup"] = "db/backup/{}.sqlite"

if __name__ == "__main__":
    os.system("clear")
    override_where()
    main(db_file)
    print("Goodbye!\n\n")

# # TODO cut this /Users/wadewilson/opt/anaconda3/envs/mstables/bin/python
#  /Users/wadewilson/PycharmProjects/mstables/main.py
"""

=================================================================
====================== Welcome to msTables ======================

Available actions:

0 - Change database file name (current name = 'mstables.sqlite')
1 - Create database tables and import latest symbols
2 - Download Morningstar data into database
3 - Erase all records from database tables
4 - Delete all database tables
5 - Erase all downloaded history from 'Fetched_urls' table
6 - Create a database back-up file

=================================================================
Enter action no:
"""

"""

=================================================================
====================== Welcome to R.A.i.Ls ======================
=================================================================

Available actions:

    - Onboarding Routine - Hidden after done
0.0 - Create username: choice of greeting or preferred pronounss
0.1 - Goal Allocation: Save, Build, Grow, Learn, Retire
0.2 - Risk Allocation: 1 to 5
0.3 - Asset Allocation: Diversified, Rent/Own, Liquidity
0.4 - Portfolio Allocation: Holdings, Exclusions, Draft
0.5 - Create Allocation Backup

=================================================================
Enter action no:
"""
