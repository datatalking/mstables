﻿# SOURCE adnrew schell
# FILENAME parsing sample_rules_output.csv

import csv
import sqlite3

# Open the CSV file and create a SQLite database
# TODO add an if not exists create to prevent overwrite
# TODO create a copy of this
with open("db/sample_rules_output.csv", newline="") as csvfile:
    reader = csv.reader(csvfile, delimiter=",")
    next(reader)  # skip the header row

    # TODO add PATH to DB
    conn = sqlite3.connect("company_data.db")
    c = conn.cursor()

    # Create the table to store the data
    c.execute(
        """CREATE TABLE IF NOT EXISTS company_data
				 (company text, sector text, industry text,
				  openprice real, yield real, avevol real,
				  CAGR_Rev real, CAGR_OpeInc real, CAGR_OpeCF real,
				  CAGR_FreeCF real, Dividend_Y10 real, Rev_Growth_Y9 real,
				  OpeInc_Growth_Y9 real, NetInc_Growth_Y9 real,
				  PE_TTM real, PB_TTM real, PS_TTM real, PC_TTM real)"""
    )

    # Loop through the CSV file and insert the data into the database
    for row in reader:
        c.execute(
            """INSERT INTO company_data
					 (company, sector, industry, openprice, yield, avevol,
					  CAGR_Rev, CAGR_OpeInc, CAGR_OpeCF, CAGR_FreeCF,
					  Dividend_Y10, Rev_Growth_Y9, OpeInc_Growth_Y9, 
					  NetInc_Growth_Y9,
					  PE_TTM, PB_TTM, PS_TTM, PC_TTM)
					 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 
					 ?, ?)""",
            row,
        )

    # Commit the changes and close the database connection
    conn.commit()
    conn.close()
