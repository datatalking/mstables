﻿# SOURCE EdX MIT MicroMasters Data Science


def bisection(f, a, b, TOL, NMAX):
    """
    Computes a root of the function f(x) = 0 using the bisection method.

    :params:
    f       - function to find the root of
    a, b    - endpoints of the interval to search in
    TOL     - tolerance for the root
    NMAX    - maximum number of iterations

    :returns:
    value of lambda differential from a root of f(x) = 0 by less than TOL,
    or "Method failed."
    if the maximum number of iterations is exceeded.
    """
    # TODO test if f(a) * f(b) < 0 or =0 then what
    if f(a) * f(b) >= 0:
        return "Endpoints do not bracket the root."

    n = 1
    while n <= NMAX:
        c = (a + b) / 2
        if f(c) == 0 or (b - a) / 2 < TOL:
            return c

        n += 1
        if f(c) * f(a) > 0:
            a = c
        else:
            b = c

    return "I'm sorry sir the bisection method algorithm failed."
