﻿# SOURCE
from pandas_ods_reader import read_ods

# base_path = "../doc/pot_stocks.ods"
# sheet_index = 1
# df = read_ods(base_path, sheet_index)
# df

import pandas as pd

df = pd.read_csv("pot_stocks.csv")
# df = read_ods(path, sheet_name)
df.head()
